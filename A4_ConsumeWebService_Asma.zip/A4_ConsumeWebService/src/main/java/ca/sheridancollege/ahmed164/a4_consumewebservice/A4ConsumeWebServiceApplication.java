//Asma Ahmed 
//991699083 

package ca.sheridancollege.ahmed164.a4_consumewebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A4ConsumeWebServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(A4ConsumeWebServiceApplication.class, args);
    }

}
