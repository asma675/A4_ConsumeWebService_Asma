// Asma Ahmed
// 991699083

export interface Book {
    id?: number;
    title: string;
    authorName: string;
    price: number;
    quantity: number;
    edit?: boolean;
}
