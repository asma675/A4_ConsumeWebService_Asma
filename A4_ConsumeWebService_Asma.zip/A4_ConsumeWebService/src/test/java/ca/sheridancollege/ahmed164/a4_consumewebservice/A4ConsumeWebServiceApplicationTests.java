//Asma Ahmed 
//991699083 

package ca.sheridancollege.ahmed164.a4_consumewebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A4ConsumeWebServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
